﻿using Microsoft.Practices.Unity;
using SignalR.Infrastructure;

[assembly: WebActivator.PreApplicationStartMethod(typeof(SignalR.Unity.UnityDependencyResolver), "Start")]

namespace SignalR.Unity.App_Start
{
    public static class UnitySignalR
    {
        public static void Start()
        {
            IUnityContainer container = CreateContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        private static IUnityContainer CreateContainer()
        {
            UnityContainer container = new UnityContainer();
            RegisterServices(container);
            return container;
        }

        private static void RegisterServices(UnityContainer container)
        {
            // TODO: load up your services here
        }
    }
}
