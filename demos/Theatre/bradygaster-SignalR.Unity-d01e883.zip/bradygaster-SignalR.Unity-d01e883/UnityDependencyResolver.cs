﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SignalR.Infrastructure;
using Microsoft.Practices.Unity;

namespace SignalR.Unity
{
    public class UnityDependencyResolver : IDependencyResolver
    {
        private IUnityContainer _container;

        public UnityDependencyResolver(IUnityContainer container)
        {
            _container = container;
        }

        public object GetService(Type serviceType)
        {
            return _container.Resolve(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return _container.ResolveAll(serviceType);
        }

        public void Register(Type serviceType, Func<object> activator)
        {
            _container.RegisterInstance(serviceType, activator());
        }

        public void Register(Type serviceType, IEnumerable<Func<object>> activators)
        {
            activators.ToList().ForEach(a =>
                {
                    var r = a();
                    _container.RegisterInstance(serviceType, r.GetType().Name, r);
                });
        }
    }
}
